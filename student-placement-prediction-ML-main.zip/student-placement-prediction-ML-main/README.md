# student-placement-prediction-ML
Machine learning code using python.
